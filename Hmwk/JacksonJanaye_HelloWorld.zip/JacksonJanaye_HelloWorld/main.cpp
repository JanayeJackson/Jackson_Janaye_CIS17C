/* 
 * File:   main.cpp
 * Author: Janaye Jackson
 * Created on 02/24/2024 9:44 AM
 * Purpose:   Create a Hello World Program to become
 *             familiar with netbeans
 */
 
//System Libraries Here
#include <iostream>//cout,cin
using namespace std;

//User Libraries Here

//Global Constants Only, No Global Variables
//Like PI, e, Gravity, or conversions

//Function Prototypes Here

//Program Execution Begins Here
int main(int argc, char** argv) {
    //Declare all Variables Here
    
    //Output
    cout<<"Hello World"<<endl;
    //Exit
    return 0;
}